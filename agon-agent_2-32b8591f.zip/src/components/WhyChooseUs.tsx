import React from 'react';
import { motion } from 'framer-motion';
import { ShieldAlert, Cpu, Award, BookOpen, Landmark, Eye } from 'lucide-react';

export default function WhyChooseUs() {
  const reasons = [
    {
      icon: <Award className="w-6 h-6 text-amber-400" />,
      title: 'U.P. Govt. Recognized',
      description: 'Fully recognized by the Uttar Pradesh Government with UDISE Code 09714104643, ensuring high academic standards.',
      badge: 'Certified'
    },
    {
      icon: <BookOpen className="w-6 h-6 text-blue-400" />,
      title: 'CBSE Pattern Curriculum',
      description: 'A robust, child-centric CBSE curriculum structure focusing on core languages, mathematics, sciences, and environmental studies.',
      badge: 'Modern'
    },
    {
      icon: <Cpu className="w-6 h-6 text-purple-400" />,
      title: 'Smart & Computer Education',
      description: 'Equipped with smart learning screens and a dedicated computer lab to introduce children to technology early.',
      badge: 'Tech-First'
    },
    {
      icon: <Eye className="w-6 h-6 text-emerald-400" />,
      title: '24/7 CCTV Security',
      description: 'The entire campus is under constant video surveillance, ensuring complete physical safety for boys and girls.',
      badge: 'Secure'
    },
    {
      icon: <Landmark className="w-6 h-6 text-rose-400" />,
      title: 'Nurturing Infrastructure',
      description: 'Spacious classrooms, cozy library, modern playground, and a clean, hygienic environment built for children.',
      badge: 'Premium'
    },
    {
      icon: <ShieldAlert className="w-6 h-6 text-cyan-400" />,
      title: 'Affordable Premium Quality',
      description: 'Providing international standards of primary schooling at an affordable fee structure tailored for local families.',
      badge: 'Best Value'
    }
  ];

  const containerVariants = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    show: { opacity: 1, y: 0, transition: { type: 'spring' as const, stiffness: 100 } }
  };

  return (
    <section id="why-choose-us" className="py-24 relative overflow-hidden bg-slate-950/40">
      {/* Background grids */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-[radial-gradient(ellipse_at_top,rgba(30,58,138,0.08),transparent_50%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-500 bg-amber-500/10 px-3.5 py-1.5 rounded-full">
            Why Him Surya Convent?
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-4">
            Setting the Standard for Primary Education
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-3">
            We blend academic discipline with modern learning techniques to foster holistic growth during the most critical years of child development.
          </p>
        </div>

        {/* Reasons Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: '-100px' }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {reasons.map((reason, idx) => (
            <motion.div
              key={idx}
              variants={itemVariants}
              className="glass-card p-8 rounded-2xl border border-white/5 relative overflow-hidden group flex flex-col justify-between"
            >
              {/* Corner Accent Badge */}
              <div className="absolute top-4 right-4 bg-white/5 border border-white/10 text-slate-400 text-[10px] font-bold px-2.5 py-1 rounded-full group-hover:bg-amber-500/10 group-hover:border-amber-500/30 group-hover:text-amber-400 transition-all duration-300">
                {reason.badge}
              </div>

              <div>
                {/* Icon Container */}
                <div className="p-3.5 rounded-xl bg-slate-900 border border-white/10 w-fit mb-6 group-hover:border-amber-500/30 group-hover:scale-110 transition-all duration-300">
                  {reason.icon}
                </div>

                {/* Title */}
                <h3 className="text-lg font-bold text-white group-hover:text-amber-400 transition-colors">
                  {reason.title}
                </h3>

                {/* Description */}
                <p className="text-slate-400 text-sm mt-3.5 leading-relaxed">
                  {reason.description}
                </p>
              </div>

              {/* Bottom line glow decoration */}
              <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-amber-500/0 via-amber-500/0 to-amber-500/0 group-hover:from-blue-500/0 group-hover:via-amber-500/50 group-hover:to-blue-500/0 transition-all duration-500" />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
