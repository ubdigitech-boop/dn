import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, Phone, MapPin, Printer, Download, Sparkles, Send, RefreshCw, X } from 'lucide-react';

interface AdmissionFormProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AdmissionForm({ isOpen, onClose }: AdmissionFormProps) {
  // Form State
  const [studentName, setStudentName] = useState('');
  const [parentName, setParentName] = useState('');
  const [appliedClass, setAppliedClass] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [message, setMessage] = useState('');

  // Status State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSubmittingSuccess] = useState(false);
  const [inquiryId, setInquiryId] = useState('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const classesList = [
    'Play Group (PG)',
    'Nursery',
    'LKG',
    'UKG',
    'Class I',
    'Class II',
    'Class III',
    'Class IV',
    'Class V'
  ];

  const validateForm = () => {
    const tempErrors: { [key: string]: string } = {};
    if (!studentName.trim()) tempErrors.studentName = 'Student name is required';
    if (!parentName.trim()) tempErrors.parentName = 'Parent name is required';
    if (!appliedClass) tempErrors.appliedClass = 'Please select a class';
    if (!phone.trim()) {
      tempErrors.phone = 'Phone number is required';
    } else if (!/^\d{10}$/.test(phone.trim())) {
      tempErrors.phone = 'Please enter a valid 10-digit phone number';
    }
    if (!address.trim()) tempErrors.address = 'Address/Village is required';

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);

    // Mock API submission latency
    setTimeout(() => {
      const generatedId = `HSC-${Math.floor(100000 + Math.random() * 900000)}`;
      setInquiryId(generatedId);
      setIsSubmitting(false);
      setIsSubmittingSuccess(true);
    }, 1500);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleReset = () => {
    setStudentName('');
    setParentName('');
    setAppliedClass('');
    setPhone('');
    setEmail('');
    setAddress('');
    setMessage('');
    setIsSubmittingSuccess(false);
    setInquiryId('');
    setErrors({});
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xl flex items-center justify-center p-4">
      {/* Scrollable Container */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 30 }}
        transition={{ type: 'spring', damping: 25, stiffness: 120 }}
        className="relative bg-slate-900 border border-white/10 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto"
      >
        {/* Background glow decoration */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-white/5 border border-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <AnimatePresence mode="wait">
          {!isSuccess ? (
            /* Form View */
            <motion.div
              key="form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              {/* Form Title */}
              <div className="mb-6">
                <span className="text-xs font-bold uppercase tracking-widest text-amber-500 bg-amber-500/10 px-2.5 py-1 rounded-md">
                  Admissions Open 2026-27
                </span>
                <h3 className="text-2xl font-black text-white mt-2">
                  Online Admission Inquiry
                </h3>
                <p className="text-slate-400 text-xs sm:text-sm mt-1">
                  Fill out this simple form, and our admissions team will get in touch with you within 24 hours.
                </p>
              </div>

              {/* Form */}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Student Name */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Student Full Name *
                    </label>
                    <input
                      type="text"
                      value={studentName}
                      onChange={(e) => setStudentName(e.target.value)}
                      placeholder="e.g. Rahul Kumar"
                      className={`w-full px-4 py-2.5 rounded-xl bg-slate-950 border text-slate-200 placeholder-slate-600 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 transition-all ${
                        errors.studentName ? 'border-rose-500/50' : 'border-white/10 focus:border-amber-500'
                      }`}
                    />
                    {errors.studentName && (
                      <span className="text-rose-500 text-[10px] mt-1 block">{errors.studentName}</span>
                    )}
                  </div>

                  {/* Parent/Guardian Name */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Parent / Guardian Name *
                    </label>
                    <input
                      type="text"
                      value={parentName}
                      onChange={(e) => setParentName(e.target.value)}
                      placeholder="e.g. Ramesh Kumar"
                      className={`w-full px-4 py-2.5 rounded-xl bg-slate-950 border text-slate-200 placeholder-slate-600 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 transition-all ${
                        errors.parentName ? 'border-rose-500/50' : 'border-white/10 focus:border-amber-500'
                      }`}
                    />
                    {errors.parentName && (
                      <span className="text-rose-500 text-[10px] mt-1 block">{errors.parentName}</span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Applied Class */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Class Seeking Admission *
                    </label>
                    <select
                      value={appliedClass}
                      onChange={(e) => setAppliedClass(e.target.value)}
                      className={`w-full px-4 py-2.5 rounded-xl bg-slate-950 border text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 transition-all ${
                        errors.appliedClass ? 'border-rose-500/50' : 'border-white/10 focus:border-amber-500'
                      }`}
                    >
                      <option value="">-- Select Class --</option>
                      {classesList.map((cls, idx) => (
                        <option key={idx} value={cls} className="bg-slate-900 text-slate-100">
                          {cls}
                        </option>
                      ))}
                    </select>
                    {errors.appliedClass && (
                      <span className="text-rose-500 text-[10px] mt-1 block">{errors.appliedClass}</span>
                    )}
                  </div>

                  {/* Phone Number */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Mobile Number (10 digits) *
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="e.g. 7398293485"
                      maxLength={10}
                      className={`w-full px-4 py-2.5 rounded-xl bg-slate-950 border text-slate-200 placeholder-slate-600 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 transition-all ${
                        errors.phone ? 'border-rose-500/50' : 'border-white/10 focus:border-amber-500'
                      }`}
                    />
                    {errors.phone && (
                      <span className="text-rose-500 text-[10px] mt-1 block">{errors.phone}</span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Email */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Email Address (Optional)
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. parent@example.com"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-slate-200 placeholder-slate-600 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition-all"
                    />
                  </div>

                  {/* Address / Village */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Address / Village / Town *
                    </label>
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="e.g. Girdharpur, Gyanpur"
                      className={`w-full px-4 py-2.5 rounded-xl bg-slate-950 border text-slate-200 placeholder-slate-600 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 transition-all ${
                        errors.address ? 'border-rose-500/50' : 'border-white/10 focus:border-amber-500'
                      }`}
                    />
                    {errors.address && (
                      <span className="text-rose-500 text-[10px] mt-1 block">{errors.address}</span>
                    )}
                  </div>
                </div>

                {/* Message */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Any Questions or Message (Optional)
                  </label>
                  <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Tell us about your child's interests, previous school, or any specific concerns..."
                    rows={3}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-slate-200 placeholder-slate-600 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition-all resize-none"
                  />
                </div>

                {/* Info Note */}
                <div className="p-3 bg-white/5 border border-white/5 rounded-xl text-[11px] text-slate-400">
                  <span className="text-amber-400 font-bold">Note:</span> By submitting this form, you authorize Him Surya Convent School to contact you via Phone/WhatsApp regarding admissions.
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full relative overflow-hidden group px-6 py-3.5 rounded-xl font-bold text-white shadow-lg glow-gold hover:scale-[1.01] active:scale-[0.99] transition-all duration-300 flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-amber-600 to-yellow-500 transition-all duration-300 group-hover:scale-105" />
                  <span className="relative flex items-center">
                    {isSubmitting ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Submitting Inquiry...
                      </>
                    ) : (
                      <>
                        Submit Inquiry <Send className="w-4 h-4 ml-2 group-hover:translate-x-1.5 transition-transform" />
                      </>
                    )}
                  </span>
                </button>
              </form>
            </motion.div>
          ) : (
            /* Success Receipt View */
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="text-center"
            >
              {/* Animation Header */}
              <div className="flex flex-col items-center space-y-3 mb-6">
                <div className="p-4 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 animate-bounce">
                  <CheckCircle2 className="w-12 h-12" />
                </div>
                <span className="text-xs font-black uppercase tracking-widest text-emerald-400">Inquiry Submitted Successfully</span>
                <h3 className="text-2xl font-black text-white">
                  Thank You, {parentName}!
                </h3>
                <p className="text-slate-400 text-sm max-w-md">
                  We have received your admission inquiry for <strong className="text-white">{studentName}</strong>. Our counselors will call you shortly.
                </p>
              </div>

              {/* Printable Receipt Card */}
              <div id="print-slip" className="bg-slate-950 border border-amber-500/30 p-6 rounded-2xl text-left shadow-2xl relative overflow-hidden mb-6">
                {/* School Watermark watermark */}
                <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none">
                  <span className="text-4xl font-extrabold tracking-widest text-white rotate-12">HIM SURYA</span>
                </div>

                <div className="flex justify-between items-start border-b border-white/10 pb-4 mb-4">
                  <div>
                    <h4 className="text-white font-bold text-sm">HIM SURYA CONVENT SCHOOL</h4>
                    <p className="text-[10px] text-slate-400">Girdharpur, Gyanpur, Bhadohi – 221304</p>
                    <p className="text-[10px] text-amber-500">Recognized • UDISE: 09714104643</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] uppercase font-bold text-slate-400">Inquiry Receipt</span>
                    <div className="text-sm font-extrabold text-amber-400 mt-1">{inquiryId}</div>
                    <p className="text-[9px] text-slate-400">Date: {new Date().toLocaleDateString()}</p>
                  </div>
                </div>

                {/* Details Table */}
                <div className="space-y-2.5 text-xs text-slate-300">
                  <div className="grid grid-cols-3 border-b border-white/5 pb-1.5">
                    <span className="font-bold text-slate-400">Student Name:</span>
                    <span className="col-span-2 text-white font-semibold">{studentName}</span>
                  </div>
                  <div className="grid grid-cols-3 border-b border-white/5 pb-1.5">
                    <span className="font-bold text-slate-400">Parent / Guardian:</span>
                    <span className="col-span-2 text-white font-semibold">{parentName}</span>
                  </div>
                  <div className="grid grid-cols-3 border-b border-white/5 pb-1.5">
                    <span className="font-bold text-slate-400">Class Applied:</span>
                    <span className="col-span-2 text-amber-400 font-bold">{appliedClass}</span>
                  </div>
                  <div className="grid grid-cols-3 border-b border-white/5 pb-1.5">
                    <span className="font-bold text-slate-400">Mobile Number:</span>
                    <span className="col-span-2 text-white font-semibold">{phone}</span>
                  </div>
                  <div className="grid grid-cols-3 border-b border-white/5 pb-1.5">
                    <span className="font-bold text-slate-400">Address/Village:</span>
                    <span className="col-span-2 text-white font-semibold">{address}</span>
                  </div>
                  {email && (
                    <div className="grid grid-cols-3 border-b border-white/5 pb-1.5">
                      <span className="font-bold text-slate-400">Email Address:</span>
                      <span className="col-span-2 text-white font-semibold">{email}</span>
                    </div>
                  )}
                </div>

                {/* Next Steps Checklist */}
                <div className="mt-5">
                  <h5 className="text-[10px] font-black uppercase tracking-wider text-amber-400 mb-2">Next Steps Checklist</h5>
                  <ul className="space-y-1.5 text-[11px] text-slate-400">
                    <li className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-500" /> Wait for our counselor's call (within 24 hours).
                    </li>
                    <li className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-500" /> Keep Aadhaar & Birth Certificate photocopy ready.
                    </li>
                    <li className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-500" /> Visit school campus for a brief interaction.
                    </li>
                  </ul>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={handlePrint}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-white/10 hover:border-amber-500/30 bg-white/5 hover:bg-white/10 text-xs font-bold text-slate-200 hover:text-white flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Printer className="w-4 h-4" /> Print Slip
                </button>
                <button
                  onClick={handleReset}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-500 text-white text-xs font-bold shadow-lg shadow-amber-500/15 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  Submit Another Inquiry
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
