import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Award, Shield, BookOpen, Clock, Heart, Users } from 'lucide-react';

export default function About() {
  const [activeTab, setActiveTab] = useState<'manager' | 'vision' | 'values'>('manager');

  const tabs = {
    manager: {
      title: "Manager's Message",
      subtitle: "Er. Rajesh Yadav, Founder & Manager",
      content: (
        <div className="space-y-4 text-slate-300 text-sm sm:text-base leading-relaxed">
          <p>
            "Welcome to <strong className="text-white">Him Surya Convent School</strong>. Our mission is to provide an outstanding education that empowers children to become confident, compassionate, and lifelong learners."
          </p>
          <p>
            We believe that every child is unique and possesses immense potential. By combining a modern <strong className="text-amber-400">CBSE-pattern curriculum</strong> with traditional values, interactive smart learning, and individual care, we ensure our students are well-prepared for their future academic journeys.
          </p>
          <p>
            Our dedicated faculty works tirelessly to create a safe, stimulating, and joyful school environment where PG to Class V children can discover, explore, and excel. We invite you to partner with us in shaping the leaders of tomorrow.
          </p>
        </div>
      ),
    },
    vision: {
      title: "Our Vision & Mission",
      subtitle: "Nurturing excellence from the very start",
      content: (
        <div className="space-y-4 text-slate-300 text-sm sm:text-base leading-relaxed">
          <div className="border-l-2 border-amber-500 pl-4 py-1">
            <h4 className="text-white font-bold mb-1">Our Vision</h4>
            <p>To be a beacon of premium, affordable, and holistic primary education in the Bhadohi region, where young minds are nurtured with knowledge, character, and innovative thinking.</p>
          </div>
          <div className="border-l-2 border-blue-500 pl-4 py-1">
            <h4 className="text-white font-bold mb-1">Our Mission</h4>
            <p>To provide a safe, modern, and stimulating atmosphere that fosters academic curiosity, ethical values, physical development, and social responsibility in every child from PG to Class V.</p>
          </div>
        </div>
      ),
    },
    values: {
      title: "Core Values",
      subtitle: "The pillars of Him Surya Convent School",
      content: (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[
            { icon: <Heart className="w-5 h-5 text-rose-400" />, name: 'Compassion & Care', desc: 'Every child is treated with love, kindness, and individual attention.' },
            { icon: <Shield className="w-5 h-5 text-emerald-400" />, name: 'Integrity & Respect', desc: 'Instilling strong moral character and respect for elders and peers.' },
            { icon: <BookOpen className="w-5 h-5 text-blue-400" />, name: 'Academic Curiosity', desc: 'Encouraging questions, creative thinking, and a love for learning.' },
            { icon: <Users className="w-5 h-5 text-amber-400" />, name: 'Collaborative Spirit', desc: 'Fostering teamwork, healthy social interaction, and communication.' }
          ].map((val, idx) => (
            <div key={idx} className="p-3 rounded-xl bg-white/5 border border-white/5 flex items-start space-x-3">
              <div className="p-2 rounded-lg bg-slate-900 border border-white/10 mt-0.5">
                {val.icon}
              </div>
              <div>
                <h5 className="text-white font-bold text-sm">{val.name}</h5>
                <p className="text-slate-400 text-xs mt-1">{val.desc}</p>
              </div>
            </div>
          ))}
        </div>
      ),
    }
  };

  return (
    <section id="about" className="py-24 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-1/2 right-0 w-80 h-80 bg-blue-900/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Visual Showcase */}
          <div className="lg:col-span-5 relative">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative rounded-3xl overflow-hidden shadow-2xl border border-white/10 glow-blue aspect-[4/5]"
            >
              <img
                src="/images/library.jpg"
                alt="School library"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
              
              {/* Overlay Content */}
              <div className="absolute bottom-6 left-6 right-6 p-6 rounded-2xl glass-panel border border-white/10">
                <div className="flex items-center space-x-3 mb-2">
                  <div className="p-2 rounded-lg bg-amber-500 text-slate-950">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-white font-black text-sm">U.P. Government Recognized</h4>
                    <p className="text-slate-300 text-xs">UDISE Code: 09714104643</p>
                  </div>
                </div>
                <p className="text-xs text-slate-400">
                  Fully compliant with standard educational guidelines, delivering top-tier primary education.
                </p>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Detailed Text & Interactive Tabs */}
          <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-amber-500">About Our School</span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-1">
                Him Surya Convent School
              </h2>
              <p className="text-slate-400 text-sm mt-2">
                Located in Girdharpur (Laxmanpatti), Gyanpur, Bhadohi – 221304.
              </p>
            </div>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Established with a commitment to academic excellence, <strong className="text-white">Him Surya Convent School</strong> is recognized by the Uttar Pradesh Government. Following the <strong className="text-amber-400">CBSE Pattern curriculum</strong>, we offer educational programs from Play Group (PG) to Class V. We focus on active learning, smart technology integration, and moral development.
            </p>

            {/* Glassmorphic Tab Buttons */}
            <div className="flex space-x-1 p-1 rounded-xl bg-slate-900/80 border border-white/10 w-full sm:w-fit">
              {(Object.keys(tabs) as Array<keyof typeof tabs>).map((tabKey) => (
                <button
                  key={tabKey}
                  onClick={() => setActiveTab(tabKey)}
                  className={`flex-1 sm:flex-initial px-4 py-2.5 rounded-lg text-xs sm:text-sm font-semibold transition-all duration-300 ${
                    activeTab === tabKey
                      ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-white shadow-md shadow-amber-500/10'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {tabs[tabKey].title}
                </button>
              ))}
            </div>

            {/* Tab content area */}
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="glass-card p-6 rounded-2xl border border-white/5 min-h-[220px] flex flex-col justify-between"
            >
              <div>
                <h4 className="text-amber-400 font-extrabold text-sm uppercase tracking-wider mb-1">
                  {tabs[activeTab].subtitle}
                </h4>
                <div className="mt-4">
                  {tabs[activeTab].content}
                </div>
              </div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
