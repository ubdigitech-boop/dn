import React from 'react';
import { motion } from 'framer-motion';
import { Award, Star, Sparkles, Flame, ShieldAlert, CheckCircle } from 'lucide-react';

export default function Achievements() {
  const achievers = [
    {
      name: 'Akash Gautam',
      achievement: 'Selected in JPN Awasiya Vidyalaya',
      description: 'Cleared the prestigious entrance exam with exceptional scores, securing a fully-funded merit-based seat.',
      badge: 'State Merit Ranker',
      color: 'from-amber-500/25 via-amber-500/5 to-transparent',
      glowColor: 'shadow-amber-500/20'
    },
    {
      name: 'Darshit Prakhar',
      achievement: 'Selected in JPN Awasiya Vidyalaya',
      description: 'Demonstrated exceptional mathematical aptitude and logical reasoning, earning admission to the elite institution.',
      badge: 'Academic Champion',
      color: 'from-blue-500/25 via-blue-500/5 to-transparent',
      glowColor: 'shadow-blue-500/20'
    },
    {
      name: 'Shivani Gautam',
      achievement: 'Selected in JPN Awasiya Vidyalaya',
      description: 'Exhibited outstanding overall academic performance and critical thinking, securing her merit selection.',
      badge: 'Top Performer',
      color: 'from-purple-500/25 via-purple-500/5 to-transparent',
      glowColor: 'shadow-purple-500/20'
    }
  ];

  return (
    <section id="achievements" className="py-24 relative overflow-hidden bg-gradient-to-b from-slate-950 to-slate-900">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-500 bg-amber-500/10 px-3.5 py-1.5 rounded-full">
            Hall of Fame
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-4 flex flex-col sm:flex-row items-center justify-center gap-2">
            <span>Celebrating Our</span>
            <span className="text-gradient-gold flex items-center gap-1">
              <Sparkles className="w-6 h-6 text-amber-400 inline animate-pulse" />
              Academic Stars
            </span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-3">
            We congratulate our brilliant students on their monumental selection to <strong className="text-white">Jay Prakash Narayan Awasiya Vidyalaya, Uttar Pradesh</strong>—a highly competitive, merit-based state boarding institution.
          </p>
        </div>

        {/* Highlight Banner of the Selection */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="glass-card-gold p-8 rounded-3xl border border-amber-500/40 mb-16 text-center max-w-4xl mx-auto relative overflow-hidden glow-gold"
        >
          {/* Decorative shine background */}
          <div className="absolute inset-0 bg-gradient-to-r from-amber-500/5 via-white/5 to-amber-500/5 animate-shine pointer-events-none" />

          <div className="relative z-10 flex flex-col items-center space-y-4">
            <div className="p-4 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 animate-pulse">
              <Award className="w-10 h-10" />
            </div>
            <span className="text-xs font-black uppercase tracking-widest text-amber-400">Official Selection Announcement</span>
            <h3 className="text-2xl sm:text-3xl font-black text-white leading-tight">
              Jay Prakash Narayan Awasiya Vidyalaya Selections
            </h3>
            <p className="text-slate-300 text-sm sm:text-base max-w-2xl leading-relaxed">
              Our students have proven their academic caliber at the state level. This monumental selection is a testament to the rigorous academic training, individual guidance, and CBSE-pattern pedagogical approach at <strong className="text-amber-400">Him Surya Convent School</strong>.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4 pt-2 text-xs text-slate-300">
              <span className="flex items-center gap-1 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-500" /> State-Level Written Exam Cleared
              </span>
              <span className="flex items-center gap-1 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-500" /> 100% Fully-Funded Boarding Seats
              </span>
              <span className="flex items-center gap-1 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-500" /> Proud Moment for Bhadohi
              </span>
            </div>
          </div>
        </motion.div>

        {/* Achievers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {achievers.map((ach, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.15 }}
              className={`glass-card p-8 rounded-3xl border border-white/5 relative overflow-hidden group flex flex-col justify-between hover:border-amber-500/30 ${ach.glowColor}`}
            >
              {/* Background Glow Ring */}
              <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl ${ach.color} rounded-bl-full opacity-60 group-hover:opacity-100 transition-opacity duration-300`} />

              <div>
                {/* Badge */}
                <div className="flex items-center space-x-1 text-xs text-amber-400 font-bold mb-4">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400 animate-spin-slow" />
                  <span>{ach.badge}</span>
                </div>

                {/* Achiever Name */}
                <h4 className="text-2xl font-black text-white group-hover:text-amber-400 transition-colors">
                  {ach.name}
                </h4>

                {/* Selection Details */}
                <div className="inline-flex items-center space-x-1.5 text-xs text-blue-400 font-extrabold mt-1 uppercase tracking-wider">
                  <Flame className="w-3.5 h-3.5 text-orange-500" />
                  <span>{ach.achievement}</span>
                </div>

                {/* Description */}
                <p className="text-slate-400 text-sm mt-4 leading-relaxed">
                  {ach.description}
                </p>
              </div>

              {/* Card Footer with Proud Seal */}
              <div className="mt-8 pt-4 border-t border-white/5 flex items-center justify-between text-xs text-slate-400">
                <span>Selected Candidate</span>
                <span className="font-extrabold text-amber-500 uppercase tracking-widest text-[10px]">UP Govt. Merit</span>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
