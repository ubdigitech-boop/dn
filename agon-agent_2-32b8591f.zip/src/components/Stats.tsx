import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, GraduationCap, Users, Award } from 'lucide-react';

export default function Stats() {
  const stats = [
    {
      icon: <ShieldCheck className="w-8 h-8 text-emerald-400" />,
      title: 'U.P. Govt Recognized',
      value: 'Recognized',
      description: 'UDISE Code: 09714104643',
      color: 'from-emerald-500/10 to-emerald-500/0',
      borderColor: 'hover:border-emerald-500/30',
    },
    {
      icon: <GraduationCap className="w-8 h-8 text-amber-400" />,
      title: 'CBSE Pattern',
      value: 'PG to Class V',
      description: 'Holistic modern curriculum',
      color: 'from-amber-500/10 to-amber-500/0',
      borderColor: 'hover:border-amber-500/30',
    },
    {
      icon: <Users className="w-8 h-8 text-blue-400" />,
      title: 'Experienced Faculty',
      value: '100% Certified',
      description: 'Experienced & caring educators',
      color: 'from-blue-500/10 to-blue-500/0',
      borderColor: 'hover:border-blue-500/30',
    },
    {
      icon: <Award className="w-8 h-8 text-purple-400" />,
      title: 'Academic Excellence',
      value: 'Outstanding',
      description: 'Proven track record of selections',
      color: 'from-purple-500/10 to-purple-500/0',
      borderColor: 'hover:border-purple-500/30',
    },
  ];

  return (
    <section className="relative py-12 z-20 -mt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className={`glass-card p-6 rounded-2xl relative overflow-hidden group border border-white/5 ${stat.borderColor}`}
            >
              {/* Background gradient on hover */}
              <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
              
              <div className="relative z-10 flex items-center space-x-4">
                <div className="p-3 rounded-xl bg-slate-900/80 border border-white/10 group-hover:border-amber-500/20 group-hover:scale-110 transition-all duration-300">
                  {stat.icon}
                </div>
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-400 group-hover:text-amber-400 transition-colors">
                    {stat.title}
                  </div>
                  <div className="text-xl font-extrabold text-white mt-1">
                    {stat.value}
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    {stat.description}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
