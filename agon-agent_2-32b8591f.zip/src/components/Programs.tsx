import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Sparkles, CheckCircle2, ChevronRight, GraduationCap } from 'lucide-react';

export default function Programs() {
  const [selectedProg, setSelectedProg] = useState<number>(0);

  const programs = [
    {
      age: 'Age: 2.5 - 3.5 Years',
      title: 'Play Group (PG) & Nursery',
      tag: 'Early Years Foundation',
      description: 'A gentle introduction to school life, focusing on sensory exploration, social interaction, and motor skills in a warm, loving, and playful environment.',
      curriculum: [
        'Sensory & tactile play activities',
        'Basic language & vocabulary development',
        'Fine & gross motor skill training',
        'Rhymes, storytelling, and music',
        'Color, shape, and animal recognition',
        'Social habits & basic toilet training'
      ],
      highlights: 'Play-way methodology with dedicated care assistants.',
      color: 'from-pink-500/10 to-pink-500/0 border-pink-500/20 text-pink-400'
    },
    {
      age: 'Age: 3.5 - 5 Years',
      title: 'LKG & UKG (Kindergarten)',
      tag: 'Pre-Primary Education',
      description: 'Prepares children for formal schooling by building strong foundational skills in reading, writing, mathematical concepts, and environmental awareness.',
      curriculum: [
        'Phonics, letter sounds & word formation',
        'Hindi and English alphabet writing',
        'Number concepts, counting & simple additions',
        'General knowledge & environmental studies',
        'Art, craft, coloring, and clay modeling',
        'Public speaking & recitation in assemblies'
      ],
      highlights: 'Smart boards and activity-based learning materials.',
      color: 'from-amber-500/10 to-amber-500/0 border-amber-500/20 text-amber-400'
    },
    {
      age: 'Age: 5 - 10 Years',
      title: 'Primary (Classes I to V)',
      tag: 'CBSE Pattern Core',
      description: 'A formal academic program aligned with CBSE standards, designed to cultivate analytical thinking, scientific curiosity, language proficiency, and strong moral character.',
      curriculum: [
        'Language Arts: English & Hindi literature & grammar',
        'Mathematics: Arithmetic, logic, and problem-solving',
        'Science & Environmental Studies (EVS)',
        'Computer Science: Digital literacy & basic programming',
        'Moral Science, General Knowledge & Art Education',
        'Physical Education, Yoga, and Sports activities'
      ],
      highlights: 'Smart classrooms, computer lab access, and regular assessments.',
      color: 'from-blue-500/10 to-blue-500/0 border-blue-500/20 text-blue-400'
    }
  ];

  return (
    <section id="curriculum" className="py-24 relative overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/3 left-0 w-96 h-96 bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-500 bg-amber-500/10 px-3.5 py-1.5 rounded-full">
            Academic Programs
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-4">
            Curriculum Tailored for Young Minds
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-3">
            Our educational pathway from PG to Class V is designed on CBSE patterns to unlock potential, promote critical thinking, and build strong core values.
          </p>
        </div>

        {/* Tabbed Program Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Program Selectors */}
          <div className="lg:col-span-4 space-y-4">
            {programs.map((prog, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedProg(idx)}
                className={`w-full text-left p-6 rounded-2xl border transition-all duration-300 relative overflow-hidden group ${
                  selectedProg === idx
                    ? 'glass-card-gold border-amber-500/40 glow-gold shadow-lg'
                    : 'glass-card border-white/5 hover:border-white/10'
                }`}
              >
                <div className="flex justify-between items-start">
                  <span className="text-xs font-bold text-slate-400 tracking-wider">
                    {prog.age}
                  </span>
                  <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-white/5 border border-white/10 ${
                    selectedProg === idx ? 'text-amber-400 border-amber-500/20' : 'text-slate-400'
                  }`}>
                    {prog.tag}
                  </span>
                </div>
                <h3 className={`text-lg font-extrabold mt-3 flex items-center transition-colors ${
                  selectedProg === idx ? 'text-white' : 'text-slate-300 group-hover:text-white'
                }`}>
                  <GraduationCap className="w-5 h-5 mr-2 text-amber-500" />
                  {prog.title}
                </h3>
                <p className="text-xs text-slate-400 mt-2 line-clamp-2">
                  {prog.description}
                </p>
                <div className="absolute right-4 bottom-4 opacity-0 group-hover:opacity-100 transition-opacity">
                  <ChevronRight className="w-4 h-4 text-amber-500" />
                </div>
              </button>
            ))}
          </div>

          {/* Right Column: Detailed Program Card View */}
          <motion.div
            key={selectedProg}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-8 glass-card p-8 rounded-3xl border border-white/10 relative overflow-hidden flex flex-col justify-between min-h-[460px]"
          >
            {/* Background glowing gradient */}
            <div className={`absolute inset-0 bg-gradient-to-br ${programs[selectedProg].color} opacity-100 transition-all duration-500 pointer-events-none`} />

            <div className="relative z-10">
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/10 pb-6 mb-6 gap-4">
                <div>
                  <span className="text-xs font-black text-amber-400 uppercase tracking-widest">
                    {programs[selectedProg].age}
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-black text-white mt-1">
                    {programs[selectedProg].title}
                  </h3>
                  <p className="text-sm text-slate-400 mt-1 font-medium italic">
                    {programs[selectedProg].tag}
                  </p>
                </div>
                <div className="p-3 bg-slate-900 border border-white/10 rounded-2xl w-fit self-start sm:self-center">
                  <BookOpen className="w-8 h-8 text-amber-500" />
                </div>
              </div>

              {/* Description */}
              <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
                {programs[selectedProg].description}
              </p>

              {/* Curriculum Grid */}
              <div>
                <h4 className="text-white font-extrabold text-sm uppercase tracking-wider mb-4 flex items-center">
                  <Sparkles className="w-4 h-4 text-amber-400 mr-2" />
                  Key Learning Areas & Subjects
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {programs[selectedProg].curriculum.map((item, index) => (
                    <div key={index} className="flex items-start space-x-2.5 text-slate-300 text-xs sm:text-sm">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Highlights Footer */}
            <div className="relative z-10 mt-8 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
              <div className="text-xs text-slate-400">
                <strong className="text-white">Methodology Highlight:</strong> {programs[selectedProg].highlights}
              </div>
              <button className="px-5 py-2.5 rounded-xl bg-white/5 border border-white/10 hover:border-amber-500/30 hover:bg-white/10 text-xs font-bold text-slate-200 hover:text-amber-400 transition-all self-start sm:self-center">
                Download Brochure
              </button>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
