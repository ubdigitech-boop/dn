import React from 'react';
import { motion } from 'framer-motion';
import { Monitor, BookOpen, ShieldCheck, Gamepad2, ScreenShare, Sparkles } from 'lucide-react';

export default function Facilities() {
  const facilities = [
    {
      icon: <ScreenShare className="w-6 h-6 text-blue-400" />,
      title: 'Smart Classrooms',
      description: 'Airy, spacious classrooms integrated with modern audio-visual learning screens, visual aids, and interactive digital boards to make learning fun and highly effective.',
      image: '/images/hero-students.jpg',
      features: ['Digital screens', 'Ergonomic seating', 'Abundant natural light']
    },
    {
      icon: <Monitor className="w-6 h-6 text-amber-400" />,
      title: 'Computer Education',
      description: 'A modern computer lab where students get hands-on experience with computers, keyboard skills, logic puzzles, and early digital literacy, matching today’s tech demands.',
      image: '/images/computer-lab.jpg',
      features: ['Individual PCs', 'Kid-friendly software', 'Structured IT syllabus']
    },
    {
      icon: <BookOpen className="w-6 h-6 text-emerald-400" />,
      title: 'Rich Library',
      description: 'A quiet, cozy library featuring a curated collection of children’s books, colorful storybooks, picture dictionaries, and moral science materials to inspire early reading habits.',
      image: '/images/library.jpg',
      features: ['Hundreds of books', 'Quiet reading zones', 'Weekly storytelling hour']
    },
    {
      icon: <Gamepad2 className="w-6 h-6 text-rose-400" />,
      title: 'Vibrant Playground',
      description: 'A safe, open-air playground equipped with modern swings, slides, sandpits, and sports gear. It is designed to foster physical health, balance, and cooperative playing.',
      image: '/images/playground.jpg',
      features: ['Safe play equipment', 'Supervised playtime', 'Sports training']
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-cyan-400" />,
      title: 'CCTV Security',
      description: 'The entire school campus is monitored 24/7 by high-definition CCTV cameras. This provides parents with absolute peace of mind regarding their children’s safety.',
      image: '/images/school-building.jpg', // can reuse or use background
      features: ['24/7 video recording', 'Gated security guards', 'Visitor tracking logs']
    },
    {
      icon: <Sparkles className="w-6 h-6 text-purple-400" />,
      title: 'Safe & Green Campus',
      description: 'A clean, green, and highly hygienic environment. It features purified drinking water, child-friendly separate washrooms, and strict sanitization protocols.',
      image: '/images/school-building.jpg',
      features: ['RO drinking water', 'Hygienic washrooms', 'Eco-friendly green campus']
    }
  ];

  return (
    <section id="facilities" className="py-24 relative overflow-hidden bg-slate-950/20">
      {/* Background decoration */}
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-500 bg-amber-500/10 px-3.5 py-1.5 rounded-full">
            Our Infrastructure
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-4">
            World-Class Facilities for Holistic Development
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-3">
            We provide a premium, safe, and highly encouraging physical space that is fully equipped to support modern educational methods.
          </p>
        </div>

        {/* Facilities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {facilities.map((fac, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: idx * 0.05 }}
              className="glass-card rounded-3xl overflow-hidden border border-white/5 relative group h-[400px] flex flex-col justify-end"
            >
              {/* Background Image with Zoom on Hover */}
              <div className="absolute inset-0 transition-transform duration-700 ease-out group-hover:scale-110">
                <img
                  src={fac.image}
                  alt={fac.title}
                  className="w-full h-full object-cover opacity-30 group-hover:opacity-40 transition-opacity duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent" />
              </div>

              {/* Facility Content Overlay */}
              <div className="p-6 relative z-10 flex flex-col justify-end h-full">
                {/* Floating Icon */}
                <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-white/10 w-fit mb-4 group-hover:border-amber-500/30 group-hover:scale-110 transition-all duration-300">
                  {fac.icon}
                </div>

                {/* Title */}
                <h3 className="text-xl font-extrabold text-white group-hover:text-amber-400 transition-colors">
                  {fac.title}
                </h3>

                {/* Description */}
                <p className="text-slate-300 text-xs sm:text-sm mt-2.5 leading-relaxed line-clamp-3 group-hover:line-clamp-none transition-all duration-500">
                  {fac.description}
                </p>

                {/* Key Features List */}
                <div className="flex flex-wrap gap-1.5 mt-4 pt-4 border-t border-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  {fac.features.map((feat, fIdx) => (
                    <span
                      key={fIdx}
                      className="text-[10px] font-bold text-slate-300 bg-white/5 border border-white/10 px-2.5 py-1 rounded-md"
                    >
                      ✓ {feat}
                    </span>
                  ))}
                </div>
              </div>

              {/* Top border glowing highlight */}
              <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-transparent to-transparent group-hover:via-amber-500/50 transition-all duration-500" />
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
