import React from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Award, BookOpen, ShieldCheck, Heart, User } from 'lucide-react';

export default function Teachers() {
  const educators = [
    {
      name: 'Er. Rajesh Yadav',
      role: 'Founder, Manager & Tech Lead',
      qualification: 'B.Tech (Computer Science), Educationalist',
      experience: '15+ Years Experience',
      specialty: 'School Administration & IT Integration',
      desc: 'An engineer turned educational visionary, Er. Rajesh Yadav founded Him Surya Convent School to bring high-tech, smart, and values-based primary education to Gyanpur, Bhadohi.',
      icon: <GraduationCap className="w-6 h-6 text-amber-500" />,
      color: 'border-amber-500/30 bg-amber-500/5'
    },
    {
      name: 'Suraj Rai',
      role: 'Principal & Head Administrator',
      qualification: 'M.A., B.Ed (Academic Leadership)',
      experience: '12+ Years Experience',
      specialty: 'Child Pedagogy & Curriculum Management',
      desc: 'Leads the academic curriculum with strict adherence to CBSE patterns, ensuring that each child from PG to Class V receives custom educational pathways and personal care.',
      icon: <Award className="w-6 h-6 text-blue-500" />,
      color: 'border-blue-500/30 bg-blue-500/5'
    },
    {
      name: 'Pushpa Yadav',
      role: 'Senior Primary Educator',
      qualification: 'B.A., B.Ed (Primary Education Specialist)',
      experience: '8+ Years Experience',
      specialty: 'EVS, Hindi & Social Sciences',
      desc: 'Specializes in environmental studies and languages. Pushpa uses story-telling and smart boards to explain complex concepts, making her a favorite among primary students.',
      icon: <BookOpen className="w-6 h-6 text-emerald-500" />,
      color: 'border-emerald-500/30 bg-emerald-500/5'
    },
    {
      name: 'Vartika Barnwal',
      role: 'Pre-Primary Coordinator',
      qualification: 'B.Sc, Nursery Trained Teacher (NTT)',
      experience: '6+ Years Experience',
      specialty: 'Early Childhood Care & Montessori Methods',
      desc: 'Manages the Play Group, Nursery, and Kindergarten divisions. Vartika is dedicated to creating a warm, sensory-rich environment where toddlers feel safe and love to learn.',
      icon: <Heart className="w-6 h-6 text-rose-500" />,
      color: 'border-rose-500/30 bg-rose-500/5'
    },
    {
      name: 'Shweta Yadav',
      role: 'Primary Language Instructor',
      qualification: 'M.A. (English Literature), B.Ed',
      experience: '5+ Years Experience',
      specialty: 'English Grammar, Phonics & Public Speaking',
      desc: 'Focuses on early language phonics, handwriting, English grammar, and public speaking. Shweta runs weekly communication drills to build confidence in young kids.',
      icon: <ShieldCheck className="w-6 h-6 text-cyan-500" />,
      color: 'border-cyan-500/30 bg-cyan-500/5'
    },
    {
      name: 'Prinka Yadav',
      role: 'Mathematics & Science Instructor',
      qualification: 'M.Sc, B.Ed (Science & Mathematics)',
      experience: '4+ Years Experience',
      specialty: 'Arithmetic, Logic & Basic Sciences',
      desc: 'Brings math and science to life with interactive models, logic puzzles, and experiments. Prinka focuses on removing the fear of numbers and building strong logical bases.',
      icon: <User className="w-6 h-6 text-purple-500" />,
      color: 'border-purple-500/30 bg-purple-500/5'
    }
  ];

  return (
    <section id="teachers" className="py-24 relative overflow-hidden bg-slate-950/40">
      {/* Decorative background glow */}
      <div className="absolute top-1/4 left-1/10 w-80 h-80 bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-500 bg-amber-500/10 px-3.5 py-1.5 rounded-full">
            Our Educators
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-4">
            Highly Experienced & Caring Faculty
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-3">
            Our teachers are the backbone of Him Surya Convent School. Certified, experienced, and deeply compassionate, they provide individual attention to every child.
          </p>
        </div>

        {/* Teachers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {educators.map((teacher, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: idx * 0.05 }}
              className={`glass-card p-8 rounded-3xl border relative overflow-hidden group flex flex-col justify-between hover:border-amber-500/30 transition-all duration-300`}
            >
              {/* Top background accent card color */}
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-blue-600 to-amber-500 opacity-80" />

              <div>
                {/* Header with Avatar and Icon */}
                <div className="flex items-center space-x-4 mb-6">
                  <div className="relative">
                    {/* Silhouette Avatar */}
                    <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-white/10 flex items-center justify-center text-slate-400 group-hover:border-amber-500/30 transition-all duration-300">
                      <User className="w-8 h-8 opacity-70 group-hover:text-amber-400 transition-colors" />
                    </div>
                    {/* Floating badge icon */}
                    <div className="absolute -bottom-1 -right-1 p-1 bg-slate-950 border border-white/10 rounded-lg group-hover:border-amber-500/30">
                      {teacher.icon}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-white group-hover:text-amber-400 transition-colors">
                      {teacher.name}
                    </h3>
                    <p className="text-xs text-amber-500 font-bold uppercase tracking-wider">
                      {teacher.role}
                    </p>
                  </div>
                </div>

                {/* Details list */}
                <div className="space-y-2 mb-6">
                  <div className="text-xs text-slate-300 flex items-center">
                    <span className="font-bold text-slate-400 mr-1.5">Qual:</span> {teacher.qualification}
                  </div>
                  <div className="text-xs text-slate-300 flex items-center">
                    <span className="font-bold text-slate-400 mr-1.5">Exp:</span> {teacher.experience}
                  </div>
                  <div className="text-xs text-slate-300 flex items-center">
                    <span className="font-bold text-slate-400 mr-1.5">Specialty:</span> {teacher.specialty}
                  </div>
                </div>

                {/* Description */}
                <p className="text-slate-400 text-xs sm:text-sm leading-relaxed border-t border-white/5 pt-4">
                  {teacher.desc}
                </p>
              </div>

              {/* Card Footer */}
              <div className="mt-8 pt-4 border-t border-white/5 flex justify-between items-center text-[10px] uppercase font-bold text-slate-500">
                <span>Him Surya Educator</span>
                <span className="text-amber-500">Verified Faculty</span>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
