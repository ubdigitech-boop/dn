import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ZoomIn, Image, Play, Camera, Heart } from 'lucide-react';

export default function Gallery() {
  const [filter, setFilter] = useState<'all' | 'campus' | 'academics' | 'activities'>('all');
  const [activePhoto, setActivePhoto] = useState<number | null>(null);

  const photos = [
    {
      id: 1,
      src: '/images/school-building.jpg',
      category: 'campus',
      title: 'School Campus Front Facade',
      description: 'The modern, premium, and welcoming exterior architecture of Him Surya Convent School.'
    },
    {
      id: 2,
      src: '/images/hero-students.jpg',
      category: 'academics',
      title: 'Smart Classroom Interaction',
      description: 'Students engaged in active learning inside our modern, multimedia-equipped smart classrooms.'
    },
    {
      id: 3,
      src: '/images/computer-lab.jpg',
      category: 'activities',
      title: 'Modern Computer Laboratory',
      description: 'Hands-on computer education introducing kids from early classes to digital literacy.'
    },
    {
      id: 4,
      src: '/images/library.jpg',
      category: 'academics',
      title: 'School Library & Study Room',
      description: 'Our cozy reading environment stocked with interactive books, storybooks, and encyclopedias.'
    },
    {
      id: 5,
      src: '/images/playground.jpg',
      category: 'activities',
      title: 'Vibrant Kids Playground',
      description: 'Children enjoying outdoor games and swings on our safe, supervised school playground.'
    },
    {
      id: 6,
      src: '/images/hero-students.jpg', // can reuse or show another
      category: 'campus',
      title: 'Safe Gated Entryways',
      description: 'Monitored gates and campus structures designed for the complete safety of students.'
    }
  ];

  const filteredPhotos = filter === 'all' ? photos : photos.filter(p => p.category === filter);

  const categories = [
    { key: 'all', label: 'All Photos' },
    { key: 'campus', label: 'Campus & Security' },
    { key: 'academics', label: 'Academics & Labs' },
    { key: 'activities', label: 'Playground & Activities' }
  ] as const;

  return (
    <section id="gallery" className="py-24 relative overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-500 bg-amber-500/10 px-3.5 py-1.5 rounded-full">
            Campus Gallery
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-4">
            A Glimpse into Life at Him Surya
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-3">
            Explore our state-of-the-art facilities, active learning environments, secure spaces, and student activities.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setFilter(cat.key)}
              className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-300 ${
                filter === cat.key
                  ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-white shadow-md shadow-amber-500/10 border-amber-500/20 border'
                  : 'text-slate-400 bg-white/5 border border-white/5 hover:text-white hover:bg-white/10'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Photos Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence mode="popLayout">
            {filteredPhotos.map((photo, index) => (
              <motion.div
                key={photo.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                onClick={() => setActivePhoto(index)}
                className="group relative aspect-[4/3] rounded-2xl overflow-hidden border border-white/5 cursor-pointer shadow-lg hover:border-amber-500/30 transition-all duration-300"
              >
                {/* Image */}
                <img
                  src={photo.src}
                  alt={photo.title}
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                />

                {/* Dark Overlay on Hover */}
                <div className="absolute inset-0 bg-slate-950/0 group-hover:bg-slate-950/80 transition-colors duration-300 flex flex-col justify-end p-6" />

                {/* Content Overlay */}
                <div className="absolute inset-0 flex flex-col justify-between p-4 z-10 pointer-events-none">
                  {/* Category Tag */}
                  <div className="self-end bg-slate-950/80 backdrop-blur-md border border-white/10 px-2.5 py-1 rounded-lg text-[10px] font-bold text-amber-400 uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    {photo.category}
                  </div>

                  {/* Title & Description */}
                  <div className="opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                    <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 w-fit mb-2">
                      <ZoomIn className="w-4 h-4" />
                    </div>
                    <h4 className="text-white font-black text-sm sm:text-base">
                      {photo.title}
                    </h4>
                    <p className="text-slate-300 text-xs mt-1 leading-relaxed line-clamp-2">
                      {photo.description}
                    </p>
                  </div>
                </div>

                {/* Tiny Border glow on hover */}
                <div className="absolute inset-0 border border-amber-500/0 group-hover:border-amber-500/30 rounded-2xl transition-colors duration-300 pointer-events-none" />
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {activePhoto !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-xl flex items-center justify-center p-4"
          >
            {/* Close Button on top right */}
            <button
              onClick={() => setActivePhoto(null)}
              className="absolute top-6 right-6 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer z-50"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Lightbox Content Container */}
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ type: 'spring', damping: 25, stiffness: 120 }}
              className="max-w-5xl w-full bg-slate-900/50 border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col lg:flex-row"
            >
              {/* Image Column */}
              <div className="lg:w-2/3 aspect-[4/3] lg:aspect-auto relative bg-black flex items-center justify-center">
                <img
                  src={filteredPhotos[activePhoto].src}
                  alt={filteredPhotos[activePhoto].title}
                  className="w-full h-full object-contain max-h-[70vh]"
                />
              </div>

              {/* Text Details Column */}
              <div className="lg:w-1/3 p-8 flex flex-col justify-between bg-slate-900/80 border-t lg:border-t-0 lg:border-l border-white/10">
                <div>
                  <span className="text-xs font-black text-amber-500 uppercase tracking-widest bg-amber-500/10 px-2.5 py-1 rounded-md">
                    {filteredPhotos[activePhoto].category}
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-white mt-4">
                    {filteredPhotos[activePhoto].title}
                  </h3>
                  <p className="text-slate-300 text-sm mt-3 leading-relaxed">
                    {filteredPhotos[activePhoto].description}
                  </p>
                </div>

                <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-xs text-slate-400">
                    <Camera className="w-4 h-4 text-amber-500" />
                    <span>Campus Tour Photo</span>
                  </div>
                  {/* Next / Prev Controls */}
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setActivePhoto((prev) => (prev !== null && prev > 0 ? prev - 1 : filteredPhotos.length - 1))}
                      className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs text-white hover:bg-white/10 transition-colors"
                    >
                      Prev
                    </button>
                    <button
                      onClick={() => setActivePhoto((prev) => (prev !== null && prev < filteredPhotos.length - 1 ? prev + 1 : 0))}
                      className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs text-white hover:bg-white/10 transition-colors"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
