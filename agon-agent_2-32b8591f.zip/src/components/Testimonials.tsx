import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, Quote, ChevronLeft, ChevronRight, User } from 'lucide-react';

export default function Testimonials() {
  const [activeIdx, setActiveIdx] = useState(0);

  const reviews = [
    {
      text: "Him Surya Convent School has exceeded our expectations. The smart classrooms and personalized attention make learning incredibly fun for our daughter. The selection of students in Jay Prakash Narayan Awasiya Vidyalaya shows their commitment to excellence!",
      author: "Dr. Alok Gautam",
      relation: "Father of Akash Gautam (Selected in JPN Vidyalaya)",
      location: "Gyanpur, Bhadohi",
      rating: 5
    },
    {
      text: "The pre-primary division (PG & Kindergarten) is exceptional. Vartika ma'am and team take care of our 3-year-old child like a mother. The campus is fully secured with CCTV cameras, which gives us complete peace of mind.",
      author: "Mrs. Sunita Devi",
      relation: "Mother of Aarav (UKG Student)",
      location: "Girdharpur, Bhadohi",
      rating: 5
    },
    {
      text: "Er. Rajesh Yadav and the teaching staff are highly professional. Introducing computer education and smart classes at such early grades is a wonderful step. My son's English speaking and basic mathematical logic have improved tremendously.",
      author: "Mr. Ramesh Yadav",
      relation: "Father of Darshit Prakhar (Selected in JPN Vidyalaya)",
      location: "Laxmanpatti, Bhadohi",
      rating: 5
    }
  ];

  const handleNext = () => {
    setActiveIdx((prev) => (prev + 1) % reviews.length);
  };

  const handlePrev = () => {
    setActiveIdx((prev) => (prev - 1 + reviews.length) % reviews.length);
  };

  return (
    <section className="py-24 relative overflow-hidden bg-slate-950/40">
      {/* Background decoration */}
      <div className="absolute top-1/2 right-1/10 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-500 bg-amber-500/10 px-3.5 py-1.5 rounded-full">
            Parents' Feedback
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-4">
            What Our Parent Community Says
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-3">
            Read real stories and testimonials from parents who have experienced the premium academic standards and caring environment of Him Surya Convent School.
          </p>
        </div>

        {/* Testimonial Carousel Container */}
        <div className="max-w-4xl mx-auto relative px-4">
          
          {/* Main Testimonial Card */}
          <div className="relative z-10">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeIdx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
                className="glass-card-gold p-8 sm:p-12 rounded-3xl border border-amber-500/20 relative overflow-hidden glow-gold"
              >
                {/* Huge Quote Icon in Background */}
                <Quote className="absolute top-6 right-8 w-24 h-24 text-amber-500/5 rotate-180 pointer-events-none" />

                <div className="flex flex-col items-center text-center space-y-6">
                  
                  {/* Star Ratings */}
                  <div className="flex items-center space-x-1">
                    {[...Array(reviews[activeIdx].rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-amber-500 text-amber-500" />
                    ))}
                  </div>

                  {/* Review Text */}
                  <p className="text-slate-100 text-base sm:text-lg md:text-xl leading-relaxed font-medium italic">
                    "{reviews[activeIdx].text}"
                  </p>

                  {/* Divider */}
                  <div className="w-12 h-0.5 bg-gradient-to-r from-transparent via-amber-500 to-transparent" />

                  {/* Parent Info */}
                  <div>
                    <h4 className="text-white font-black text-base sm:text-lg">
                      {reviews[activeIdx].author}
                    </h4>
                    <p className="text-amber-400 text-xs sm:text-sm font-bold uppercase tracking-wider mt-0.5">
                      {reviews[activeIdx].relation}
                    </p>
                    <p className="text-slate-400 text-xs mt-1">
                      {reviews[activeIdx].location}
                    </p>
                  </div>

                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Slider Navigation Buttons */}
          <div className="flex justify-center items-center space-x-4 mt-8">
            <button
              onClick={handlePrev}
              className="p-3 rounded-full bg-slate-900 border border-white/10 text-slate-300 hover:text-white hover:border-amber-500/30 transition-all cursor-pointer"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="flex space-x-1.5">
              {reviews.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActiveIdx(i)}
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    activeIdx === i ? 'bg-amber-500 w-6' : 'bg-slate-700 hover:bg-slate-600'
                  }`}
                />
              ))}
            </div>
            <button
              onClick={handleNext}
              className="p-3 rounded-full bg-slate-900 border border-white/10 text-slate-300 hover:text-white hover:border-amber-500/30 transition-all cursor-pointer"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

        </div>
      </div>
    </section>
  );
}
