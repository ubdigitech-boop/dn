import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, ArrowRight, ShieldCheck, Award, BookOpen, Users } from 'lucide-react';

interface HeroProps {
  onOpenAdmissionModal: () => void;
}

export default function Hero({ onOpenAdmissionModal }: HeroProps) {
  const handleScrollToContact = () => {
    const contactSection = document.querySelector('#contact');
    if (contactSection) {
      const offset = 80;
      const elementPosition = contactSection.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center pt-24 lg:pt-32 pb-16 overflow-hidden">
      {/* Decorative Floating Orbs */}
      <div className="absolute top-1/4 left-1/10 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-float pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/10 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl animate-float-delayed pointer-events-none" />
      
      {/* Grid Pattern Background overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Text Content */}
          <div className="lg:col-span-7 flex flex-col justify-center space-y-6 text-left">
            {/* Glowing Admission Tag */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center space-x-2 bg-gradient-to-r from-amber-500/15 to-blue-500/15 border border-amber-500/30 px-4 py-1.5 rounded-full w-fit self-start animate-pulse-glow"
            >
              <Sparkles className="w-4 h-4 text-amber-500 animate-spin-slow" />
              <span className="text-xs md:text-sm font-semibold tracking-wide text-amber-300 uppercase">
                Admissions Open 2026-27
              </span>
            </motion.div>

            {/* Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-white leading-[1.1]"
            >
              Shaping Minds,<br />
              <span className="text-gradient-gold">Nurturing Hearts,</span><br />
              Inspiring Futures.
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-base sm:text-lg text-slate-300 max-w-xl leading-relaxed font-normal"
            >
              Providing premium quality education from <strong className="text-white">PG to Class V</strong> with highly experienced teachers, smart learning systems, and a nurturing environment on the <strong className="text-amber-400">CBSE Pattern</strong>.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2"
            >
              <button
                onClick={onOpenAdmissionModal}
                className="group relative overflow-hidden px-8 py-4 rounded-xl font-bold text-white shadow-lg glow-gold hover:scale-[1.02] active:scale-[0.98] transition-all duration-300 flex items-center justify-center space-x-2"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-amber-600 to-yellow-500 transition-all duration-300 group-hover:scale-105" />
                <span className="relative flex items-center">
                  Apply Now <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1.5 transition-transform" />
                </span>
              </button>

              <button
                onClick={handleScrollToContact}
                className="px-8 py-4 rounded-xl font-bold border border-white/10 hover:border-amber-500/50 hover:bg-white/5 text-slate-200 hover:text-white transition-all duration-300 flex items-center justify-center space-x-2"
              >
                <span>Contact Us</span>
              </button>
            </motion.div>

            {/* Quick Recognition Badges */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
              className="pt-6 border-t border-white/5 flex flex-wrap gap-y-3 gap-x-6 text-xs text-slate-400"
            >
              <div className="flex items-center space-x-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>U.P. Government Recognized</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <Award className="w-4 h-4 text-amber-500" />
                <span>UDISE: 09714104643</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <BookOpen className="w-4 h-4 text-blue-400" />
                <span>CBSE Pattern Curriculum</span>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Premium Interactive Stacked Cards */}
          <div className="lg:col-span-5 relative h-[380px] sm:h-[480px] w-full flex items-center justify-center mt-8 lg:mt-0">
            {/* Main Image Card (Top/Floating) */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, rotate: -2 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="absolute w-[80%] sm:w-[75%] aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl border border-white/10 z-20 glow-blue animate-float"
            >
              <img
                src="/images/hero-students.jpg"
                alt="Happy students in a classroom"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <span className="bg-amber-500 text-slate-950 text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider">
                  Nurturing Environment
                </span>
                <h4 className="text-white font-bold text-sm sm:text-base mt-1.5 shadow-sm">
                  Interactive Smart Classrooms
                </h4>
              </div>
            </motion.div>

            {/* Back Image Card (Offset & Rotated) */}
            <motion.div
              initial={{ opacity: 0, scale: 0.85, rotate: 6 }}
              animate={{ opacity: 1, scale: 0.95, rotate: 6 }}
              transition={{ duration: 1, delay: 0.4 }}
              className="absolute w-[80%] sm:w-[75%] aspect-[4/3] rounded-2xl overflow-hidden shadow-xl border border-white/5 z-10 translate-x-8 -translate-y-6 opacity-70 hover:opacity-100 hover:z-30 transition-all duration-300"
            >
              <img
                src="/images/school-building.jpg"
                alt="Modern school campus building"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <span className="bg-blue-600 text-white text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider">
                  Premium Campus
                </span>
                <h4 className="text-white font-bold text-sm sm:text-base mt-1.5">
                  State-of-the-Art Infrastructure
                </h4>
              </div>
            </motion.div>

            {/* Small Floating Stats Card */}
            <motion.div
              initial={{ opacity: 0, x: -30, y: 30 }}
              animate={{ opacity: 1, x: -40, y: 50 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="absolute bottom-4 left-2 sm:left-6 z-30 glass-card-gold p-4 rounded-xl max-w-[180px] border border-amber-500/30 animate-float-delayed"
            >
              <div className="flex items-center space-x-2">
                <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">Student Ratio</div>
                  <div className="text-sm font-extrabold text-white">20:1 Ratio</div>
                </div>
              </div>
            </motion.div>

            {/* Small Floating Pattern Card */}
            <motion.div
              initial={{ opacity: 0, x: 30, y: -30 }}
              animate={{ opacity: 1, x: 50, y: -60 }}
              transition={{ duration: 0.8, delay: 0.7 }}
              className="absolute top-8 right-2 sm:right-6 z-30 glass-card p-3.5 rounded-xl max-w-[160px] border border-white/10"
            >
              <div className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">Affiliated to</div>
              <div className="text-sm font-extrabold text-white mt-0.5">CBSE Pattern</div>
              <div className="text-[10px] text-slate-400 mt-1">PG to Class V</div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
