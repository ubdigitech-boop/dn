import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Phone, MapPin, Mail, Clock, Send, CheckCircle2, Award, Sparkles, MessageSquare } from 'lucide-react';

export default function Contact() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [msg, setMsg] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1200);
  };

  const handleReset = () => {
    setName('');
    setPhone('');
    setMsg('');
    setSubmitted(false);
  };

  const contactInfo = [
    {
      icon: <Phone className="w-5 h-5 text-amber-400" />,
      title: 'Contact Numbers',
      details: (
        <div className="space-y-1 text-slate-300 text-sm">
          <p className="flex items-center">
            <a href="tel:7398293485" className="hover:text-amber-400 transition-colors font-bold">7398293485</a>
            <span className="mx-1.5 text-slate-500">/</span>
            <a href="tel:9129471101" className="hover:text-amber-400 transition-colors font-bold">9129471101</a>
          </p>
          <p className="text-xs text-slate-400">Available for calls: 8:00 AM - 4:00 PM</p>
        </div>
      ),
      cta: (
        <div className="flex gap-2 mt-2">
          <a
            href="tel:7398293485"
            className="px-3 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 text-xs font-bold border border-amber-500/20 transition-all"
          >
            Call Now
          </a>
          <a
            href="https://wa.me/917398293485?text=Hello%20Him%20Surya%20Convent%20School,%20I%20want%20to%20inquire%20about%20admissions."
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 text-xs font-bold border border-emerald-500/20 transition-all"
          >
            WhatsApp
          </a>
        </div>
      )
    },
    {
      icon: <MapPin className="w-5 h-5 text-blue-400" />,
      title: 'School Campus Address',
      details: (
        <div className="space-y-0.5 text-slate-300 text-sm leading-relaxed">
          <p className="font-bold text-white">Girdharpur (Laxmanpatti)</p>
          <p>Gyanpur, Bhadohi – 221304</p>
          <p className="text-xs text-slate-400">Uttar Pradesh, India</p>
        </div>
      ),
      cta: (
        <a
          href="https://maps.google.com/?q=Girdharpur+Laxmanpatti+Gyanpur+Bhadohi"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block mt-2 px-3 py-1 rounded-lg bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 text-xs font-bold border border-blue-500/20 transition-all"
        >
          View on Google Maps
        </a>
      )
    },
    {
      icon: <Clock className="w-5 h-5 text-purple-400" />,
      title: 'Operating Hours',
      details: (
        <div className="space-y-1 text-slate-300 text-sm">
          <p className="font-bold text-white">Monday – Saturday</p>
          <p>Summer: 7:30 AM – 1:30 PM</p>
          <p>Winter: 8:30 AM – 2:30 PM</p>
        </div>
      ),
      cta: null
    }
  ];

  return (
    <section id="contact" className="py-24 relative overflow-hidden bg-slate-950/20">
      {/* Background decoration */}
      <div className="absolute bottom-1/4 left-1/10 w-96 h-96 bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-500 bg-amber-500/10 px-3.5 py-1.5 rounded-full">
            Contact Us
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-4">
            Get in Touch with Our Team
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-3">
            Have questions about admissions, academic curriculum, fee structures, or campus facilities? Feel free to reach out.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
          {/* Left Column: Contact Details */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            <div className="space-y-6">
              {contactInfo.map((info, idx) => (
                <div key={idx} className="glass-card p-6 rounded-2xl border border-white/5 flex items-start space-x-4">
                  <div className="p-3 rounded-xl bg-slate-900 border border-white/10 mt-0.5">
                    {info.icon}
                  </div>
                  <div className="flex-1">
                    <h4 className="text-white font-extrabold text-sm mb-2 uppercase tracking-wider">{info.title}</h4>
                    {info.details}
                    {info.cta}
                  </div>
                </div>
              ))}
            </div>

            {/* Premium Trust Seal */}
            <div className="glass-card-gold p-6 rounded-2xl border border-amber-500/20 flex items-center space-x-4">
              <div className="p-3 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <h5 className="text-white font-bold text-sm">UP Government Recognized</h5>
                <p className="text-slate-400 text-xs mt-0.5">UDISE Code: 09714104643</p>
                <p className="text-[10px] text-amber-500 font-bold uppercase tracking-widest mt-1">CBSE Pattern Curriculum</p>
              </div>
            </div>
          </div>

          {/* Right Column: Stylized Mock Map & Quick Message Form */}
          <div className="lg:col-span-7 glass-card p-8 rounded-3xl border border-white/10 flex flex-col justify-between relative overflow-hidden">
            {/* Background Map Graphic Accent */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(30,58,138,0.1),transparent_70%)] pointer-events-none" />

            {!submitted ? (
              <form onSubmit={handleSubmit} className="space-y-5 relative z-10">
                <div>
                  <h3 className="text-xl font-extrabold text-white flex items-center">
                    <MessageSquare className="w-5 h-5 text-amber-500 mr-2" />
                    Send a Quick Message
                  </h3>
                  <p className="text-slate-400 text-xs mt-1">
                    Leave your name and phone number, and we will call you back.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Ramesh Kumar"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-slate-200 placeholder-slate-600 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      pattern="[0-9]{10}"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="e.g. 7398293485"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-slate-200 placeholder-slate-600 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Your Message (Optional)
                  </label>
                  <textarea
                    value={msg}
                    onChange={(e) => setMsg(e.target.value)}
                    placeholder="Ask about fee structures, transport, timings, etc."
                    rows={4}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-slate-200 placeholder-slate-600 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition-all resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full relative overflow-hidden group px-6 py-3 rounded-xl font-bold text-white shadow-lg glow-gold hover:scale-[1.01] active:scale-[0.99] transition-all duration-300 flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-amber-600 to-yellow-500 transition-all duration-300 group-hover:scale-105" />
                  <span className="relative flex items-center">
                    {loading ? 'Sending Message...' : 'Send Message'}
                    {!loading && <Send className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />}
                  </span>
                </button>
              </form>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-12 relative z-10 flex flex-col items-center justify-center h-full space-y-4"
              >
                <div className="p-4 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 animate-bounce">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h4 className="text-xl font-black text-white">Message Sent Successfully!</h4>
                <p className="text-slate-300 text-sm max-w-sm">
                  Thank you for reaching out, <strong className="text-white">{name}</strong>. Our support staff will call you on <strong className="text-white">{phone}</strong> shortly.
                </p>
                <button
                  onClick={handleReset}
                  className="px-5 py-2 rounded-lg bg-white/5 border border-white/10 text-xs font-bold text-slate-300 hover:text-white transition-all cursor-pointer"
                >
                  Send Another Message
                </button>
              </motion.div>
            )}

            {/* Stylized Mock Map Graphic bottom */}
            <div className="mt-8 border-t border-white/5 pt-6">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Campus Location Map</h4>
              <div className="h-36 rounded-2xl bg-slate-950 border border-white/10 relative overflow-hidden flex items-center justify-center group">
                {/* Background grid representing a map */}
                <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:16px_16px]" />
                <div className="absolute inset-0 bg-gradient-to-tr from-blue-900/10 via-transparent to-amber-500/5" />
                
                {/* Visual marker */}
                <div className="relative z-10 flex flex-col items-center">
                  <div className="p-2.5 rounded-full bg-amber-500 text-slate-950 animate-bounce shadow-lg">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-black uppercase text-white tracking-widest mt-2 bg-slate-900/90 border border-white/10 px-2 py-0.5 rounded-md">
                    Him Surya Convent School
                  </span>
                </div>

                <a
                  href="https://maps.google.com/?q=Girdharpur+Laxmanpatti+Gyanpur+Bhadohi"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="absolute inset-0 bg-slate-950/0 group-hover:bg-slate-950/40 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100 duration-300"
                >
                  <span className="bg-amber-500 text-slate-950 text-xs font-black px-4 py-2 rounded-xl shadow-lg transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                    Open in Google Maps
                  </span>
                </a>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
