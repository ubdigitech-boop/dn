import React from 'react';
import { GraduationCap, Sun, Phone, MapPin, Award, Shield, Heart } from 'lucide-react';

interface FooterProps {
  onOpenAdmissionModal: () => void;
}

export default function Footer({ onOpenAdmissionModal }: FooterProps) {
  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetElement = document.querySelector(href);
    if (targetElement) {
      const offset = 80;
      const elementPosition = targetElement.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <footer className="bg-slate-950 border-t border-white/5 pt-16 pb-8 relative overflow-hidden">
      {/* Background glow overlay */}
      <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-blue-900/10 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 border-b border-white/5 pb-12 mb-10">
          
          {/* Column 1: School Branding */}
          <div className="lg:col-span-4 space-y-4">
            <a href="#" className="flex items-center space-x-2.5 group">
              <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-900 to-slate-900 border border-amber-500/40 shadow-md">
                <Sun className="w-5 h-5 text-amber-500 absolute animate-spin-slow" />
                <GraduationCap className="w-3.5 h-3.5 text-white relative z-10" />
              </div>
              <div className="flex flex-col">
                <span className="text-base font-black tracking-tight text-white leading-none">
                  HIM SURYA <span className="text-amber-400 font-extrabold">CONVENT</span>
                </span>
                <span className="text-[9px] text-slate-400 font-medium tracking-widest uppercase mt-0.5">
                  School • Gyanpur Bhadohi
                </span>
              </div>
            </a>
            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed max-w-sm">
              Providing premium, CBSE-pattern primary education (PG to Class V) with smart technology and moral foundations under U.P. Government recognition.
            </p>
            <div className="flex items-center space-x-2.5 text-xs text-slate-400">
              <span className="flex items-center text-amber-400">
                <Award className="w-3.5 h-3.5 mr-1" /> UDISE: 09714104643
              </span>
              <span>•</span>
              <span className="text-slate-300 font-bold">PG to Class V</span>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-white font-black text-xs uppercase tracking-wider">Quick Links</h4>
            <div className="grid grid-cols-2 gap-2 text-xs sm:text-sm">
              {[
                { name: 'About School', href: '#about' },
                { name: 'Why Choose Us', href: '#why-choose-us' },
                { name: 'Curriculum', href: '#curriculum' },
                { name: 'Facilities', href: '#facilities' },
                { name: 'Achievements', href: '#achievements' },
                { name: 'Our Teachers', href: '#teachers' },
                { name: 'Campus Gallery', href: '#gallery' },
                { name: 'Contact Us', href: '#contact' },
              ].map((link, idx) => (
                <a
                  key={idx}
                  href={link.href}
                  onClick={(e) => handleScrollTo(e, link.href)}
                  className="text-slate-400 hover:text-amber-400 transition-colors"
                >
                  {link.name}
                </a>
              ))}
            </div>
          </div>

          {/* Column 3: Contact Info */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-white font-black text-xs uppercase tracking-wider">Contact Info</h4>
            <ul className="space-y-3 text-xs sm:text-sm text-slate-400">
              <li className="flex items-start space-x-2.5">
                <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <span className="leading-relaxed">
                  Girdharpur (Laxmanpatti),<br />
                  Gyanpur, Bhadohi – 221304,<br />
                  Uttar Pradesh, India
                </span>
              </li>
              <li className="flex items-center space-x-2.5">
                <Phone className="w-4 h-4 text-amber-500 shrink-0" />
                <div className="flex flex-col">
                  <a href="tel:7398293485" className="hover:text-amber-400 transition-colors font-bold text-white">7398293485</a>
                  <a href="tel:9129471101" className="hover:text-amber-400 transition-colors font-bold text-white">9129471101</a>
                </div>
              </li>
            </ul>
          </div>

          {/* Column 4: Admissions CTA */}
          <div className="lg:col-span-2 space-y-4">
            <h4 className="text-white font-black text-xs uppercase tracking-wider">Admissions</h4>
            <p className="text-slate-400 text-xs leading-relaxed">
              Admissions are open for the academic session 2026-27. Secure your child's seat today!
            </p>
            <button
              onClick={onOpenAdmissionModal}
              className="w-full text-center px-4 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-500 hover:scale-105 transition-all text-white font-bold text-xs shadow-md shadow-amber-500/10 cursor-pointer"
            >
              Apply Online
            </button>
          </div>

        </div>

        {/* Bottom copyright bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} Him Surya Convent School. All Rights Reserved.</p>
          <div className="flex items-center space-x-4">
            <span className="flex items-center">
              Made with <Heart className="w-3 h-3 text-rose-500 mx-1 fill-rose-500" /> for early education excellence
            </span>
            <span>|</span>
            <span className="text-slate-400 font-medium">U.P. Govt. Recognized</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
