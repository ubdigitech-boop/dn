import React, { useState, useEffect } from 'react';
import { Menu, X, GraduationCap, Sun, Phone, Award } from 'lucide-react';

interface NavbarProps {
  onOpenAdmissionModal: () => void;
}

export default function Navbar({ onOpenAdmissionModal }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Why Choose Us', href: '#why-choose-us' },
    { name: 'Curriculum', href: '#curriculum' },
    { name: 'Facilities', href: '#facilities' },
    { name: 'Achievements', href: '#achievements' },
    { name: 'Teachers', href: '#teachers' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Contact', href: '#contact' },
  ];

  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsOpen(false);
    const targetElement = document.querySelector(href);
    if (targetElement) {
      const offset = 80; // height of navbar
      const elementPosition = targetElement.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'glass-nav py-3 shadow-lg' : 'bg-transparent py-5'
    }`}>
      {/* Top Banner for UDISE & Recognition */}
      {!isScrolled && (
        <div className="hidden lg:block border-b border-white/5 pb-2 mb-3 px-6">
          <div className="max-w-7xl mx-auto flex justify-between items-center text-xs text-slate-300 font-medium">
            <div className="flex items-center space-x-4">
              <span className="flex items-center text-amber-400">
                <Award className="w-3.5 h-3.5 mr-1" /> U.P. Govt Recognized
              </span>
              <span className="text-slate-400">|</span>
              <span>UDISE Code: <strong className="text-slate-100">09714104643</strong></span>
              <span className="text-slate-400">|</span>
              <span className="text-amber-400 font-semibold">CBSE Pattern Curriculum</span>
            </div>
            <div className="flex items-center space-x-4">
              <a href="tel:7398293485" className="flex items-center hover:text-amber-400 transition-colors">
                <Phone className="w-3.5 h-3.5 mr-1 text-amber-500 animate-pulse" /> +91 7398293485
              </a>
              <span>/</span>
              <a href="tel:9129471101" className="hover:text-amber-400 transition-colors">+91 9129471101</a>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo & School Name */}
          <a href="#" className="flex items-center space-x-2.5 group">
            <div className="relative flex items-center justify-center w-11 h-11 rounded-xl bg-gradient-to-tr from-blue-900 to-slate-900 border border-amber-500/40 shadow-md overflow-hidden group-hover:border-amber-400 transition-all duration-300">
              <div className="absolute inset-0 bg-amber-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <Sun className="w-6 h-6 text-amber-500 absolute animate-spin-slow" />
              <GraduationCap className="w-4 h-4 text-white relative z-10 mt-1" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg md:text-xl font-bold tracking-tight text-white leading-tight flex items-center">
                HIM SURYA <span className="text-amber-400 font-extrabold ml-1">CONVENT</span>
              </span>
              <span className="text-[10px] text-slate-300 font-medium tracking-widest uppercase">
                School • Gyanpur Bhadohi
              </span>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <div className="hidden lg:flex items-center space-x-1">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleScrollTo(e, link.href)}
                className="px-3.5 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 rounded-lg hover:bg-white/5 transition-all duration-200"
              >
                {link.name}
              </a>
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden lg:flex items-center space-x-4">
            <button
              onClick={onOpenAdmissionModal}
              className="relative overflow-hidden group px-5 py-2.5 rounded-xl font-semibold text-sm transition-all duration-300 glow-gold"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-amber-600 to-yellow-500 transition-all duration-300 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-500 to-amber-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <span className="relative text-white flex items-center">
                Apply Now <span className="ml-1.5 group-hover:translate-x-1 transition-transform">→</span>
              </span>
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="flex lg:hidden items-center space-x-2">
            <button
              onClick={onOpenAdmissionModal}
              className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-600 to-yellow-500 text-white font-semibold text-xs shadow-md shadow-amber-500/20 hover:scale-105 active:scale-95 transition-all"
            >
              Apply
            </button>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-colors focus:outline-none"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`lg:hidden transition-all duration-300 ease-in-out ${
        isOpen ? 'max-h-screen opacity-100 py-4 border-b border-white/10 glass-nav' : 'max-h-0 opacity-0 overflow-hidden'
      }`}>
        <div className="px-4 pt-2 pb-3 space-y-1">
          {/* Mobile Info */}
          <div className="px-3 py-2 bg-white/5 rounded-lg mb-3 text-xs text-slate-300 space-y-1">
            <div className="flex justify-between">
              <span className="text-amber-400">UDISE: 09714104643</span>
              <span>PG to Class V</span>
            </div>
            <div className="text-slate-400 text-[11px]">U.P. Govt. Recognized • CBSE Pattern</div>
          </div>
          
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={(e) => handleScrollTo(e, link.href)}
              className="block px-4 py-2.5 rounded-lg text-base font-medium text-slate-300 hover:text-amber-400 hover:bg-white/5 transition-all"
            >
              {link.name}
            </a>
          ))}
          
          <div className="pt-4 border-t border-white/5 px-3">
            <button
              onClick={() => {
                setIsOpen(false);
                onOpenAdmissionModal();
              }}
              className="w-full flex items-center justify-center px-4 py-3 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-500 text-white font-semibold text-sm shadow-lg shadow-amber-500/20"
            >
              Admissions Open 2026-27 - Apply Now
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
