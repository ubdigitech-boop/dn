import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Phone, MessageSquare, ArrowUp, Sparkles, Award } from 'lucide-react';

// Component Imports
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Stats from './components/Stats';
import About from './components/About';
import WhyChooseUs from './components/WhyChooseUs';
import Programs from './components/Programs';
import Facilities from './components/Facilities';
import Achievements from './components/Achievements';
import Teachers from './components/Teachers';
import Gallery from './components/Gallery';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import AdmissionForm from './components/AdmissionForm';

export default function App() {
  const [isAdmissionModalOpen, setIsAdmissionModalOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [showFloatingWidget, setShowFloatingWidget] = useState(false);

  // Handle scroll events
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setShowScrollTop(true);
        setShowFloatingWidget(true);
      } else {
        setShowScrollTop(false);
        setShowFloatingWidget(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <div className="relative min-h-screen selection:bg-amber-500 selection:text-slate-950">
      
      {/* Background Static Stars/Particles simulation */}
      <div className="fixed inset-0 z-0 pointer-events-none opacity-20">
        <div className="absolute top-10 left-1/4 w-1 h-1 bg-white rounded-full" />
        <div className="absolute top-40 right-1/3 w-1.5 h-1.5 bg-amber-400 rounded-full animate-pulse" />
        <div className="absolute bottom-1/3 left-1/10 w-1 h-1 bg-white rounded-full animate-pulse" />
        <div className="absolute bottom-10 right-10 w-1 h-1 bg-blue-400 rounded-full" />
        <div className="absolute top-2/3 right-1/12 w-1.5 h-1.5 bg-white rounded-full" />
      </div>

      {/* Header / Navigation */}
      <Navbar onOpenAdmissionModal={() => setIsAdmissionModalOpen(true)} />

      {/* Main Content Sections */}
      <main className="relative z-10">
        {/* Hero Landing Section */}
        <Hero onOpenAdmissionModal={() => setIsAdmissionModalOpen(true)} />
        
        {/* Statistics Floating Banner */}
        <Stats />
        
        {/* About School Section */}
        <About />
        
        {/* Why Choose Us Section */}
        <WhyChooseUs />
        
        {/* Academic Programs Section */}
        <Programs />
        
        {/* Facilities Section */}
        <Facilities />
        
        {/* Student Achievements Section */}
        <Achievements />
        
        {/* Experienced Teachers Section */}
        <Teachers />
        
        {/* Gallery Section */}
        <Gallery />
        
        {/* Testimonials Section */}
        <Testimonials />
        
        {/* Contact Us Section */}
        <Contact />
      </main>

      {/* Footer Section */}
      <Footer onOpenAdmissionModal={() => setIsAdmissionModalOpen(true)} />

      {/* Admission Inquiry Modal */}
      <AnimatePresence>
        {isAdmissionModalOpen && (
          <AdmissionForm
            isOpen={isAdmissionModalOpen}
            onClose={() => setIsAdmissionModalOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Interactive Floating Action Buttons (Bottom Right) */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end space-y-3 pointer-events-none">
        
        {/* Floating Quick Admission Badge */}
        <AnimatePresence>
          {showFloatingWidget && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8, x: 50 }}
              animate={{ opacity: 1, scale: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.8, x: 50 }}
              onClick={() => setIsAdmissionModalOpen(true)}
              className="pointer-events-auto flex items-center space-x-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-amber-600 to-yellow-500 text-white font-bold text-xs shadow-lg glow-gold hover:scale-105 active:scale-95 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 animate-spin-slow" />
              <span>Admission Open 26-27</span>
            </motion.button>
          )}
        </AnimatePresence>

        {/* Floating WhatsApp Quick Link */}
        <AnimatePresence>
          {showFloatingWidget && (
            <motion.a
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 20 }}
              href="https://wa.me/917398293485?text=Hello%20Him%20Surya%20Convent%20School,%20I%20want%20to%20inquire%20about%20admissions."
              target="_blank"
              rel="noopener noreferrer"
              className="pointer-events-auto p-3.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg hover:scale-110 active:scale-95 transition-all cursor-pointer flex items-center justify-center border border-emerald-500/20"
              title="Chat with Admissions on WhatsApp"
            >
              <MessageSquare className="w-5 h-5 fill-white text-emerald-600" />
            </motion.a>
          )}
        </AnimatePresence>

        {/* Floating Call Quick Link */}
        <AnimatePresence>
          {showFloatingWidget && (
            <motion.a
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 20 }}
              href="tel:7398293485"
              className="pointer-events-auto p-3.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white shadow-lg hover:scale-110 active:scale-95 transition-all cursor-pointer flex items-center justify-center border border-blue-500/20"
              title="Call Admissions Desk"
            >
              <Phone className="w-5 h-5 fill-white text-blue-600" />
            </motion.a>
          )}
        </AnimatePresence>

        {/* Scroll to Top Button */}
        <AnimatePresence>
          {showScrollTop && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={handleScrollToTop}
              className="pointer-events-auto p-3 rounded-full bg-slate-900/90 border border-white/10 text-slate-300 hover:text-white hover:border-amber-500/30 shadow-lg hover:scale-110 active:scale-95 transition-all cursor-pointer"
              title="Scroll to Top"
            >
              <ArrowUp className="w-4 h-4" />
            </motion.button>
          )}
        </AnimatePresence>
      </div>

    </div>
  );
}
